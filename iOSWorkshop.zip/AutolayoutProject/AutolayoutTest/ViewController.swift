//
//  ViewController.swift
//  AutolayoutTest
//
//  Created by Jeremy on 4/4/16.
//  Copyright © 2016 Jeremy March. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var mylabel:UILabel?
    @IBOutlet weak var myTextField:UITextField?
    
    @IBAction func setText(sender: UIButton) {
        mylabel!.text = myTextField!.text;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myTextField!.borderStyle = UITextBorderStyle.Line
        
        //myTextField!.frame = CGRectMake(140 , 440, myTextField!.frame.width, myTextField!.frame.height)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

