//
//  ViewController.swift
//  DrawingProject
//
//  Created by Jeremy on 4/5/16.
//  Copyright © 2016 Jeremy March. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let point = CGPoint(x: 100, y: 100)
        let imageSize = CGSize(width: 200, height: 200)
        drawCircle(point, imageSize: imageSize)
    }
    
    func drawCircle(origin: CGPoint, imageSize: CGSize)
    {
        let imageView = UIImageView(frame: CGRect(origin: origin, size: imageSize))
        self.view.addSubview(imageView)
        
        //Make an image from a PNG file
        let imageName = "redCircle.png"
        let image1 = UIImage(named: imageName)
        
        //or draw it with code
        let image2 = drawCircleWithCode(origin, size:imageSize)
        
        
        imageView.image = image2
    }
    
    func drawCircleWithCode(origin: CGPoint, size: CGSize) -> UIImage {
        // Setup our context
        let opaque = false //false means the background is transparent, true opaque

        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        CGContextSetLineWidth(context, 6.0)
        CGContextSetStrokeColorWithColor(context, UIColor.blueColor().CGColor)
        let rectangle = CGRectMake(4,4,size.width - 8,size.height - 8)
        CGContextAddEllipseInRect(context, rectangle)
        
        CGContextStrokePath(context)
        
        // Drawing complete, retrieve the finished image and cleanup
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    /*
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if let touch = touches.first {
            let point = touch.locationInView(view)
            
            let imageSize = CGSize(width: 200, height: 200)
            drawCircle(point, imageSize: imageSize)
        }
        super.touchesBegan(touches, withEvent:event)
    }
    */
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

