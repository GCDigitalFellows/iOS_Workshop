//
//  ViewController.swift
//  GestureProject
//
//  Created by Jeremy on 4/4/16.
//  Copyright © 2016 Jeremy March. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var mylabel:UILabel?
    
    func recognizePinchGesture(_ sender: UIPinchGestureRecognizer)
    {
        //NSLog("pinch: %f, %f", sender.scale, sender.velocity)
        
        let velocityThreshold:CGFloat = 2.0
        if sender.scale > 1 && sender.velocity > velocityThreshold {
            NSLog("Spread velocity: %f", sender.velocity)
        }
        else if  sender.velocity < (velocityThreshold * -1) {
            NSLog("Pinch velocity: %f", sender.velocity)
        }
        
        //Now add a UILabel
        mylabel!.font = mylabel!.font.withSize(7 * sender.scale)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        
        let pinchGesture: UIPinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: #selector(recognizePinchGesture(_:)))
        view.addGestureRecognizer(pinchGesture)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

