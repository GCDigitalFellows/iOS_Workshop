//
//  ViewController.swift
//  DrawingProject
//
//  Created by Jeremy on 4/5/16.
//  Copyright © 2016 Jeremy March. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let point = CGPoint(x: 100, y: 100)
        let imageSize = CGSize(width: 200, height: 200)
        drawCircle(point, imageSize: imageSize)
    }
    
    func drawCircle(_ origin: CGPoint, imageSize: CGSize)
    {
        let imageView = UIImageView(frame: CGRect(origin: origin, size: imageSize))
        self.view.addSubview(imageView)
        
        //Make an image from a PNG file
        let imageName = "redCircle.png"
        let image1 = UIImage(named: imageName)
        
        //or draw it with code
        let image2 = drawCircleWithCode(origin, size:imageSize)
        
        
        imageView.image = image2
    }
    
    func drawCircleWithCode(_ origin: CGPoint, size: CGSize) -> UIImage {
        // Setup our context
        let opaque = false //false means the background is transparent, true opaque

        let scale: CGFloat = 0
        UIGraphicsBeginImageContextWithOptions(size, opaque, scale)
        let context = UIGraphicsGetCurrentContext()
        
        context?.setLineWidth(6.0)
        context?.setStrokeColor(UIColor.blue.cgColor)
        let rectangle = CGRect(x: 4,y: 4,width: size.width - 8,height: size.height - 8)
        context?.addEllipse(in: rectangle)
        
        context?.strokePath()
        
        // Drawing complete, retrieve the finished image and cleanup
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    /*
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            let point = touch.location(in: view)
            
            let imageSize = CGSize(width: 200, height: 200)
            drawCircle(point, imageSize: imageSize)
        }
        super.touchesBegan(touches, with:event)
    }
 */
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

